Welcome to the IFN/ENIT-database demo-samples!

Thank you for your interest. 
You have got a small part of the IFN/ENIT-database. 
(10 randomly selected writers from the "set_a"; =569 handwritten Tunisian town/village names)


Please remember: The IFN/ENIT-database is free for non-commerial research. 

Have a nice day.

Mario Pechwitz

-----------------------------------------------------------------------------------------------
http://www.ifnenit.com
